﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using fuurai_generic;
namespace village_chief
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btLoadData_Click(object sender, EventArgs e)
        {
            string filepath = "";
            string exp = "op_R【測定データ】(*.csv)|*.csv";
            FileReadWrite frw = new FileReadWrite();
            filepath = frw.FileSelect(exp, 0, "", Directory.GetCurrentDirectory());

            string strHeader = frw.LoadData(filepath, "UTF-8");
            if (strHeader != "Position_mm,Opening_um") { MessageBox.Show("ファイルが違います。");return; }



            var distances = LoadDistanceData(filepath);

            if (distances.Count < 10)
            {
                Console.WriteLine("データが少なすぎます。");
                return;
            }

            var result = PatternJudge.Judge(distances);

            Console.WriteLine("---- 判定結果 ----");
            Console.WriteLine($"判定パターン : {result.Pattern}");
            Console.WriteLine($"信頼スコア   : {result.Score:F3}");
            Console.WriteLine($"平均値       : {result.Mean:F4}");
            Console.WriteLine($"分散         : {result.Variance:F4}");
            txtHantei.Text = "";
            txtHantei.Text += ("---- 判定結果 ----\n");
            txtHantei.Text += ($"判定パターン : {result.Pattern}\n");
            txtHantei.Text += ($"信頼スコア   : {result.Score:F3}\n");
            txtHantei.Text += ($"平均値       : {result.Mean:F4}\n");
            txtHantei.Text += ($"分散         : {result.Variance:F4} \n");
        }



        // CSVから距離列を読む（2列目想定）
        static List<double> LoadDistanceData(string path)
        {
            var list = new List<double>();

            foreach (var line in File.ReadLines(path))
            {
                var cols = line.Split(',');
                if (cols.Length < 2) continue;

                if (double.TryParse(cols[1],
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out double value))
                {
                    list.Add(value);
                }
            }

            return list;
        }
    }

    // ---------------- 判定ロジック ----------------

    static class PatternJudge
    {
        // 基準モデル
        static readonly PatternModel[] Models =
        {
            new PatternModel("L", 25.7, 0.4),
            new PatternModel("M", 26.9, 0.4),
            new PatternModel("T", 28.2, 0.5),
        };

        public static JudgeResult Judge(List<double> data)
        {
            double mean = data.Average();
            double variance = data.Select(x => (x - mean) * (x - mean)).Average();

            PatternModel best = null;
            double bestScore = double.MaxValue;

            foreach (var model in Models)
            {
                double score =
                    Math.Abs(mean - model.Mean) +
                    Math.Abs(variance - model.Variance);

                if (score < bestScore)
                {
                    bestScore = score;
                    best = model;
                }
            }

            return new JudgeResult
            {
                Pattern = best.Name,
                Score = bestScore,
                Mean = mean,
                Variance = variance
            };
        }
    }

    class PatternModel
    {
        public string Name;
        public double Mean;
        public double Variance;

        public PatternModel(string name, double mean, double variance)
        {
            Name = name;
            Mean = mean;
            Variance = variance;
        }
    }

    class JudgeResult
    {
        public string Pattern;
        public double Score;
        public double Mean;
        public double Variance;
    }

}
